import type { CloudgateAuth, CloudgateAuthOptions, CloudgateSession } from './index.js';
export interface PlatformRequestOptions { method?: string; body?: unknown; signal?: AbortSignal; timeoutMs?: number }
export interface PlatformRequest { <T = Record<string, any>>(path: string, options?: PlatformRequestOptions): Promise<T> }
export class CloudgatePlatformError extends Error {
  status: number; code: string; body?: unknown; url?: string;
  constructor(message: string, info?: { status?: number; code?: string; body?: unknown; url?: string });
}
export function createIdpClient(options: { auth: CloudgateAuth; apiUrl: string; fetchImpl?: typeof fetch; timeoutMs?: number; anonymous?: boolean }): PlatformRequest;
export const createIdpAdminClient: typeof createIdpClient;
export interface AppIdentity { webAppId: string; environment: string }
export interface PublishedApp { webAppId: string; isProduction: boolean }
export type IdentityResolver = () => Promise<AppIdentity>;
export function isWebAppId(value: unknown): boolean;
export function createAppIdentityResolver(options?: { webAppId?: string; environment?: string; resolvePublishedApp?: () => Promise<PublishedApp | null> }): IdentityResolver;
export function createPublishedAnalyticsResolver(options?: { readWindow?: () => unknown; fetchImpl?: typeof fetch }): () => Promise<PublishedApp | null>;
export interface IdpProfile { isEmailConfirmed?: boolean | null; promptForEmailVerification?: boolean; id: number | string; name?: string; surname?: string; email?: string; role?: string | null; photoUrl?: string | null }
export function normalizeProfile(raw: unknown): IdpProfile;
export function getProfileDisplayName(profile: Partial<IdpProfile>): string;
export function getProfilePictureSrc(profile: Partial<IdpProfile>): string | undefined;
export const PROFILE_PICTURE_MAX_BYTES: number;
export const PROFILE_PICTURE_TYPES: string[];
export interface ProfilePictureResult { profilePictureId: string | null; photoUrl: string | null }
export function createProfileClient(options: { request: PlatformRequest }): {
  get(options?: PlatformRequestOptions): Promise<IdpProfile>;
  resendVerification(options?: PlatformRequestOptions): Promise<{ sent: boolean; isEmailConfirmed: boolean; retryAfterSeconds: number }>;
  update(values: Pick<IdpProfile, 'name' | 'surname' | 'email'>, options?: PlatformRequestOptions): Promise<IdpProfile>;
  uploadPicture(file: Blob, options?: PlatformRequestOptions): Promise<ProfilePictureResult>;
  removePicture(options?: PlatformRequestOptions): Promise<ProfilePictureResult>;
};
export interface AccountLink { linked: boolean; available: boolean; userId?: number | null; displayName?: string | null; email?: string | null; linkedAtUtc?: string | null; photoUrl?: string | null; profilePictureId?: string | null }
export interface AccountLinkTicket { code: string; expiresAt: string; authorizationUrl: string }
export interface DeveloperWorkspaceLaunch { frameUrl: string; frameOrigin: string; projectName: string; appName: string; environment: 'sbx' | 'prod'; controllerId?: string | null; controllerName?: string | null; controllerPath?: string | null }
export function createDeveloperWorkspaceClient(options: { request: PlatformRequest; resolveAppIdentity: IdentityResolver; projectPath?: string }): {
  open(input: { returnUrl: string }, options?: PlatformRequestOptions): Promise<DeveloperWorkspaceLaunch>;
};
export function isDeveloperWorkspaceMessage(event: MessageEvent, frameWindow: Window | null, frameOrigin: string): boolean;
export interface RegistrationSettings { allowSelfRegistration: boolean; promptForEmailVerification?: boolean; scope: 'tenant' }
export interface EmailTemplateSettings { templateEnabled: boolean; templateHtml: string; scope: 'tenant' }
export const EMAIL_TEMPLATE_MAX_LENGTH: number;
export const EMAIL_TEMPLATE_FIELDS: readonly string[];
export function validateEmailTemplate(values: { templateEnabled: boolean; templateHtml: string }): string | null;
export function createEmailTemplateClient(options: { request: PlatformRequest }): {
  get(options?: PlatformRequestOptions): Promise<EmailTemplateSettings>;
  update(values: { templateEnabled: boolean; templateHtml: string }, options?: PlatformRequestOptions): Promise<EmailTemplateSettings>;
};
export function createRegistrationClient(options: { request: PlatformRequest }): {
  get(options?: PlatformRequestOptions): Promise<RegistrationSettings>;
  update(values: { allowSelfRegistration: boolean; promptForEmailVerification?: boolean }, options?: PlatformRequestOptions): Promise<RegistrationSettings>;
};
export function createAccountLinkClient(options: { request: PlatformRequest }): {
  get(options?: PlatformRequestOptions): Promise<AccountLink>;
  start(input: { returnUrl: string }, options?: PlatformRequestOptions): Promise<AccountLinkTicket>;
  complete(input: { code: string }, options?: PlatformRequestOptions): Promise<AccountLink | { pending: true }>;
  detach(options?: PlatformRequestOptions): Promise<AccountLink>;
};
export type AppearanceValues = Record<string, string>;
export interface AppearanceSnapshot { values: AppearanceValues; revision: string }
export function createAppearanceClient(options: { request: PlatformRequest; publicRequest?: PlatformRequest; webAppId?: string; environment?: string; resolveAppIdentity?: IdentityResolver }): {
  getPublic(): Promise<AppearanceSnapshot & { allowSelfRegistration: boolean }>;
  get(): Promise<AppearanceSnapshot>; save(values: AppearanceValues, revision: string): Promise<AppearanceSnapshot>; reset(revision: string): Promise<AppearanceSnapshot>;
};
export const DEFAULT_SETTINGS: Readonly<AppearanceValues>;
export const THEME_PRESETS: Array<[string, string, string]>;
export function normalizeSettings(values?: Partial<AppearanceValues>): AppearanceValues;
export function validateSettings(values: AppearanceValues): string | null;
export function isHex(value: unknown): boolean;
export function safeUrl(value: string): boolean;
export function rgb(hex: string): string;
export function foreground(hex: string): string;
export function accentText(hex: string, dark: boolean): string;
export const ADMIN_ROLES: readonly string[];
export function isAdminRole(role: unknown): boolean;
export interface IdpRolePermission { key: string; value: string }
export interface IdpManagedRole { id: number | null; name: string; isDefault: boolean; userCount: number; permissions: IdpRolePermission[] }
export interface IdpRoleSave { id?: number | null; name: string; permissions: IdpRolePermission[] }
export function createRolesClient(options: { request: PlatformRequest }): {
  list(options?: PlatformRequestOptions): Promise<{ items: IdpManagedRole[] }>;
  create(values: IdpRoleSave, options?: PlatformRequestOptions): Promise<IdpManagedRole>;
  update(values: IdpRoleSave, options?: PlatformRequestOptions): Promise<IdpManagedRole>;
  delete(id: number, options?: PlatformRequestOptions): Promise<{ deleted: boolean }>;
};
export function validateRole(values: IdpRoleSave): string | null;
export const MEDIA_FOLDERS: readonly string[];
export function createFilesClient(options: { request: PlatformRequest; resolveAppIdentity: IdentityResolver; mediaFolder?: string }): {
  list(query?: { path?: string; skip?: number; take?: number; signal?: AbortSignal }): Promise<Record<string, any>>;
  upload(file: File, path?: string, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  delete(id: string, options?: PlatformRequestOptions): Promise<Record<string, any>>;
};
export interface AppInvitationResult { user: Record<string, any>; created: boolean; invitation: { sent: boolean; appName: string; appUrl: string } }
export function createUsersClient(options: { request: PlatformRequest; resolveAppIdentity?: IdentityResolver; readLocation?: () => Pick<Location, 'hostname' | 'protocol' | 'origin'> | undefined }): {
  list(query?: { filter?: string; skip?: number; take?: number }, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  get(id: number, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  create(user: Record<string, unknown>, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  invitationApp(options?: PlatformRequestOptions): Promise<{ webAppId: string; name: string; url: string; isDevelopment?: boolean }>;
  invite(user: { email: string; name?: string; surname?: string; phoneNumber?: string }, options?: PlatformRequestOptions): Promise<AppInvitationResult>;
  resendInvite(id: number, options?: PlatformRequestOptions): Promise<AppInvitationResult>;
  update(user: Record<string, unknown>, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  setRole(id: number, role: string, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  setActive(id: number, isActive: boolean, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  requestPasswordReset(id: number, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  delete(id: number, options?: PlatformRequestOptions): Promise<Record<string, any>>;
};
export function createSmtpClient(options: { request: PlatformRequest }): {
  get(options?: PlatformRequestOptions): Promise<Record<string, any>>;
  update(values: Record<string, unknown>, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  delete(options?: PlatformRequestOptions): Promise<Record<string, any>>;
  sendTest(to: string, options?: PlatformRequestOptions): Promise<Record<string, any>>;
};
export interface CloudgatePayment { id: number; isProduction: boolean; grossAmount: number; applicationFeeAmount: number; currency: string; status: number; reference?: string | null; description?: string | null; paymentUrl?: string | null; refundedAmount: number; creationTime: string; paidAt?: string | null }
export function safePaymentUrl(value: unknown): string | null;
export function createPaymentsClient(options: { request: PlatformRequest; environment?: string; resolveAppIdentity?: IdentityResolver }): {
  status(query?: { environment?: string }): Promise<Record<string, any>>;
  list(query?: { environment?: string; skip?: number; take?: number; status?: number | null }, options?: PlatformRequestOptions): Promise<{ items: CloudgatePayment[]; totalCount: number }>;
  createTest(input: { amount: number; currency: string; description: string; reference?: string; idempotencyKey: string; returnUrl: string }, options?: PlatformRequestOptions): Promise<CloudgatePayment>;
};
export function safeNotificationLink(value: unknown): string | null;
export type NotificationStyle = 'info' | 'success' | 'warning' | 'danger';
export const NOTIFICATION_STYLES: readonly NotificationStyle[];
export interface NotificationDraft {
  allUsers: boolean; userId?: number; title: string; body: string; style?: NotificationStyle;
  actionUrl?: string | null; actionLabel?: string | null;
}
export interface NotificationHistoryItem {
  id: string; title: string; body: string; style: NotificationStyle; creationTime: string;
  actionUrl?: string | null; actionLabel?: string | null; isBroadcast: boolean;
  recipientCount: number; readCount: number; senderIdpUserId?: number | null; workflowNodeId?: string | null;
}
export interface NotificationRecipient { userId: number; email?: string | null; isRead: boolean; readAtUtc?: string | null }
export type NotificationEnvironment = 'sbx' | 'sandbox' | 'prod' | 'production';
export interface NotificationHistoryQuery { environment?: NotificationEnvironment; skip?: number; take?: number }
export function validateNotification(values: NotificationDraft): string | null;
export function createNotificationAdminClient(options: { request: PlatformRequest; resolveAppIdentity: IdentityResolver }): {
  history(query?: NotificationHistoryQuery, options?: PlatformRequestOptions): Promise<{ items: NotificationHistoryItem[]; totalCount: number }>;
  recipients(query: NotificationHistoryQuery & { id: string; isRead?: boolean }, options?: PlatformRequestOptions): Promise<{ items: NotificationRecipient[]; totalCount: number }>;
  send(values: NotificationDraft & { environment: NotificationEnvironment }, options?: PlatformRequestOptions): Promise<{ id: string; recipientCount: number }>;
};
export function notificationAppearance(style: string): Record<string, string>;
export function createNotificationsClient(options: { request: PlatformRequest; resolveAppIdentity: IdentityResolver }): {
  list(query?: { skip?: number; take?: number; unreadOnly?: boolean }): Promise<Record<string, any>>;
  unreadCount(): Promise<{ unreadCount: number }>; read(id: string): Promise<Record<string, any>>; readAll(): Promise<Record<string, any>>;
};
export interface NotificationSocketOptions {
  apiUrl: string; environment: string; getAccessToken: () => Promise<string | null> | string | null;
  onChange: () => void; onStatus?: (status: string) => void; WebSocketImpl?: typeof WebSocket;
  retryDelayMs?: number; heartbeatMs?: number; handshakeMs?: number;
}
export function connectNotificationSocket(options: NotificationSocketOptions): () => void;
export class AppAnalyticsError extends CloudgatePlatformError { constructor(message: string, status?: number, code?: string) }
export class WorkflowLogsError extends CloudgatePlatformError { constructor(message: string, status?: number, code?: string) }
export interface AnalyticsQuery { timePeriod?: number; skip?: number; take?: number; pagePath?: string; signal?: AbortSignal }
export interface FeatureScope { projectPath: string; environment: string; readonly isProduction: boolean; readonly configured: boolean }
export function createAppAnalyticsClient(options: { request?: PlatformRequest; auth?: CloudgateAuth; apiUrl?: string; projectPath?: string; environment?: string; preview?: boolean; fetchImpl?: typeof fetch; resolvePublishedApp?: () => Promise<PublishedApp | null> }): {
  scope: FeatureScope; overview(timePeriod?: number, options?: { signal?: AbortSignal }): Promise<Record<string, any>>;
  pages(query?: AnalyticsQuery): Promise<Record<string, any>>; sessions(query?: AnalyticsQuery): Promise<Record<string, any>>;
};
export function createWorkflowLogsClient(options: { request: PlatformRequest; projectPath?: string; resolveAppIdentity: IdentityResolver }): {
  scope: FeatureScope; list(query?: Record<string, unknown> & { signal?: AbortSignal }): Promise<Record<string, any>>;
  summary(periodHours?: number, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  get(id: string, options?: PlatformRequestOptions): Promise<Record<string, any>>;
  nodes(sessionId: string, options?: PlatformRequestOptions): Promise<Array<Record<string, any>>>;
};
export const ANALYTICS_PERIODS: Array<[number, string]>;
export function count(value?: number | null): string;
export function duration(value?: number | null): string;
export function percent(value?: number | null): string;
export function comparison(current?: number | null, previous?: number | null): { text: string; direction: string };
export function countryName(code?: string): string;
export function visitorName(row: Record<string, unknown>): string;
export function analyticsDateRange(period: number, now?: Date): { startDate?: string; endDate?: string };
export interface AccountSecurityStatus { email: string; isEmailConfirmed: boolean; twoFactorEnabled: boolean; recoveryCodesRemaining: number }
export interface TwoFactorChallenge { requiresTwoFactor: true; challengeToken: string }
export interface IdpTokens { accessToken: string; refreshToken: string; expiresIn: number; returnUrl?: string }
export type TwoFactorHandler = (challenge: TwoFactorChallenge) => Promise<IdpTokens>;
export interface SecurityChange { security: AccountSecurityStatus; recoveryCodes: string[] | null; tokens: IdpTokens | null }
export function createAccountSecurityClient(options: { request: PlatformRequest; auth: CloudgateAuth }): {
  get(options?: PlatformRequestOptions): Promise<AccountSecurityStatus>;
  beginSetup(options?: PlatformRequestOptions): Promise<{ manualEntryKey: string; authenticatorUri: string; expiresAtUtc: string; qrCodeDataUrl: string }>;
  confirmSetup(code: string, options?: PlatformRequestOptions): Promise<SecurityChange>;
  disable(code: string, options?: PlatformRequestOptions): Promise<SecurityChange>;
  regenerateRecoveryCodes(code: string, options?: PlatformRequestOptions): Promise<SecurityChange>;
};
export function completeTwoFactorLogin(options: { apiUrl: string; tenancyName: string; challengeToken: string; code: string; fetchImpl?: typeof fetch; signal?: AbortSignal }): Promise<IdpTokens>;
export function consumeLauncherLogin(options: { apiUrl: string; tenancyName: string; webAppId?: string; auth: CloudgateAuth; onTwoFactorRequired?: TwoFactorHandler; fetcher?: typeof fetch; location?: Location; history?: History }): Promise<unknown>;
export interface CloudgatePlatformOptions extends Omit<CloudgateAuthOptions, 'idpBaseUrl'> {
  idpBaseUrl?: string; apiUrl?: string; returnUrl?: string; webAppId?: string; environment?: string;
  projectPath?: string; gatewayUrl?: string; mediaFolder?: string; timeoutMs?: number; auth?: CloudgateAuth;
  resolvePublishedApp?: () => Promise<PublishedApp | null>;
}
export interface CloudgatePlatform {
  config: Readonly<{ idpBaseUrl: string; apiUrl: string; tenancyName: string; returnUrl: string; webAppId: string; environment: string; projectPath: string; gatewayUrl: string }>;
  auth: CloudgateAuth; request: PlatformRequest; resolveAppIdentity: IdentityResolver;
  profile: ReturnType<typeof createProfileClient>; accountSecurity: ReturnType<typeof createAccountSecurityClient>; accountLink: ReturnType<typeof createAccountLinkClient>;
  developerWorkspace: ReturnType<typeof createDeveloperWorkspaceClient>;
  registration: ReturnType<typeof createRegistrationClient>;
  emailTemplate: ReturnType<typeof createEmailTemplateClient>;
  notificationAdmin: ReturnType<typeof createNotificationAdminClient>;
  appearance: ReturnType<typeof createAppearanceClient>; files: ReturnType<typeof createFilesClient>;
  roles: ReturnType<typeof createRolesClient>;
  users: ReturnType<typeof createUsersClient>; smtp: ReturnType<typeof createSmtpClient>;
  analytics: ReturnType<typeof createAppAnalyticsClient>; logs: ReturnType<typeof createWorkflowLogsClient>;
  payments: ReturnType<typeof createPaymentsClient>;
  notifications: ReturnType<typeof createNotificationsClient> & { connect(options: Omit<NotificationSocketOptions, 'apiUrl' | 'environment' | 'getAccessToken'>): () => void };
  initialize(options?: { onTwoFactorRequired?: TwoFactorHandler }): Promise<CloudgateSession | null>; loginUrl(returnUrl?: string): string; login(returnUrl?: string): string; signupUrl(returnUrl?: string): string;
}
export function createCloudgatePlatform(options?: CloudgatePlatformOptions): CloudgatePlatform;
