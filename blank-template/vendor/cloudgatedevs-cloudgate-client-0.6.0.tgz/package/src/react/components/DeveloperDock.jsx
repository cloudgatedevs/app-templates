import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { Terminal, ChevronUp, ChevronDown, LockKeyhole, RefreshCw, X } from 'lucide-react';
import { useCloudgate } from '../context.jsx';
import { useAuthContext } from '../auth/index.js';
import { isDeveloperWorkspaceMessage } from '../../platform/developer-workspace.js';

export function DeveloperDock() {
  const { client } = useCloudgate();
  const { currentUser } = useAuthContext();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false), [launch, setLaunch] = useState(null);
  const [status, setStatus] = useState('idle'), [error, setError] = useState('');
  const frame = useRef(null), abort = useRef(null), generation = useRef(0), closing = useRef(null), toggle = useRef(null), minimize = useRef(null);
  const reset = () => {
    clearTimeout(closing.current);
    generation.current++; abort.current?.abort(); setLaunch(null); setStatus('idle'); setOpen(false); setError('');
  };
  const end = () => {
    if (!launch || !frame.current?.contentWindow) { reset(); return; }
    setStatus('ending');
    frame.current.contentWindow.postMessage({ source: 'cloudgate-app', type: 'end' }, launch.frameOrigin);
    // Keep the frame alive until it has initiated revocation and acknowledged the message.
    closing.current = setTimeout(reset, 5000);
  };
  useEffect(() => { reset(); return () => { generation.current++; abort.current?.abort(); clearTimeout(closing.current); }; }, [client, currentUser?.user?.id]);
  const start = async () => {
    abort.current?.abort(); abort.current = new AbortController();
    const attempt = ++generation.current;
    setLaunch(null); setStatus('connecting'); setError('');
    try {
      const result = await client.developerWorkspace.open({ returnUrl: window.location.href }, { signal: abort.current.signal });
      if (attempt === generation.current) setLaunch(result);
    } catch (err) {
      if (attempt === generation.current) { setStatus('error'); setError(err.message || 'Developer mode could not be opened.'); }
    }
  };
  useEffect(() => {
    if (!launch) return;
    const receive = event => {
      if (!isDeveloperWorkspaceMessage(event, frame.current?.contentWindow, launch.frameOrigin)) return;
      if (event.data.type === 'environment') {
        if (['prod', 'sbx'].includes(event.data.environment)) setLaunch(value => value ? { ...value, environment: event.data.environment } : value);
      } else if (event.data.type === 'ready') { setStatus('ready'); setError(''); }
      else if (event.data.type === 'ended') { reset(); }
      else {
        setStatus('error');
        setError(event.data.type === 'expired' ? 'Developer access ended. Reopen the workspace to verify your linked account.' : 'Cloudgate could not open this developer session. Reconnect to try again.');
        setLaunch(null);
      }
    };
    window.addEventListener('message', receive);
    return () => window.removeEventListener('message', receive);
  }, [launch]);
  useEffect(() => {
    if (status !== 'connecting' || !launch) return;
    const timeout = setTimeout(() => {
      setError('Cloudgate is taking too long to load. Check that the hub allows this app to embed /developer, then reconnect.');
      setStatus('error');
    }, 45000);
    return () => clearTimeout(timeout);
  }, [status, launch?.frameUrl]);
  useEffect(() => {
    if (!open) return;
    minimize.current?.focus();
    const keydown = event => { if (event.key === 'Escape' && !event.defaultPrevented) setOpen(false); };
    document.addEventListener('keydown', keydown);
    return () => { document.removeEventListener('keydown', keydown); toggle.current?.focus(); };
  }, [open]);
  const show = () => { setOpen(true); if (!launch && status !== 'connecting') void start(); };
  return <>
    <div className="developer-dock">
      <button ref={toggle} type="button" onClick={() => open ? setOpen(false) : show()} aria-expanded={open} aria-controls="cloudgate-developer-panel">
        <Terminal size={16} /><span>Developers</span><span className="developer-dock-status">{launch ? launch.projectName : 'Cloudgate workspace'}</span>
        <ChevronUp size={16} className="developer-dock-chevron" aria-hidden="true" />
      </button>
      <span className="developer-dock-access"><LockKeyhole size={12} />Linked Cloudgate account</span>
    </div>
    {createPortal(<>
        <div className="developer-backdrop" data-state={open ? 'open' : 'closed'} aria-hidden="true" onClick={() => setOpen(false)} />
        <section role="dialog" aria-labelledby="cloudgate-developer-title" aria-describedby="cloudgate-developer-description"
          aria-hidden={!open} inert={open ? undefined : ''} data-state={open ? 'open' : 'closed'} id="cloudgate-developer-panel" className="developer-panel">
          <header className="developer-panel-header">
            <div><h2 id="cloudgate-developer-title"><Terminal size={17} />Developer workspace</h2>
              <p id="cloudgate-developer-description">{launch ? `${launch.projectName} · ${launch.appName}` : 'Build and monitor the APIs behind your application.'}</p></div>
            <span className="developer-project-lock"><LockKeyhole size={12} />Project locked</span>
            {launch && <span className={`developer-env ${launch.environment === 'prod' ? 'is-production' : ''}`}>{launch.environment === 'prod' ? 'Production' : 'Sandbox'}</span>}
            {launch && <button type="button" className="developer-icon" onClick={end} disabled={status === 'ending'} aria-label="End developer session"><X size={18} /></button>}
            <button ref={minimize} type="button" className="developer-icon" onClick={() => setOpen(false)} aria-label="Minimize developer workspace"><ChevronDown size={20} /></button>
          </header>
          <div className="developer-panel-body">
            {status === 'connecting' && <div className="developer-connecting" role="status"><RefreshCw size={16} className="animate-spin" />Connecting to Cloudgate…</div>}
            {status === 'ending' && <div className="developer-connecting" role="status">Ending developer session…</div>}
            {error && <div className="developer-recovery"><Terminal size={28} /><h2>Developer access</h2><p role="alert">{error}</p>
              <p>Developer mode uses the permissions of your linked Cloudgate account. Manage the link in your profile.</p>
              <div><button className="btn-primary" onClick={start}>Reconnect</button><button className="btn-ghost" onClick={() => { end(); navigate('/profile'); }}>Open my profile</button></div></div>}
            {launch && <iframe ref={frame} title="Cloudgate developer workspace" src={launch.frameUrl}
              sandbox="allow-scripts allow-same-origin allow-forms allow-downloads allow-modals" referrerPolicy="no-referrer" />}
          </div>
        </section>
      </>, document.body)}
  </>;
}
