import { Users, UserPlus, ChartNoAxesCombined, Palette, PanelTop, Mail, Images, Activity, Wallet, Bell, Settings2 } from 'lucide-react';
import { navigationTrail } from './navigation.js';

export const PLATFORM_NAV = [{
  id: 'cloudgate-administration', label: 'Administration', icon: Settings2, section: 'platform',
  children: [
    { id: 'insights', label: 'Insights', icon: ChartNoAxesCombined, children: [
      { to: '/analytics', label: 'Analytics', icon: ChartNoAxesCombined },
      { to: '/logs', label: 'Logs', icon: Activity },
    ] },
    { to: '/payments', label: 'Payments', icon: Wallet, keywords: ['billing', 'wallet'] },
    { id: 'people', label: 'People & access', icon: Users, children: [
      { to: '/users', label: 'User management', icon: Users },
      { to: '/roles', label: 'Roles', icon: Users, keywords: ['permissions', 'access'] },
      { to: '/registration', label: 'Registration', icon: UserPlus, keywords: ['sign up', 'signup', 'self-registration', 'allow'] },
      { to: '/app-notifications', label: 'App notifications', icon: Bell, keywords: ['send', 'create', 'broadcast', 'recipients', 'read receipts'] },
    ] },
    { id: 'content', label: 'Content & email', icon: Images, children: [
      { to: '/media', label: 'Media server', icon: Images, keywords: ['files', 'images', 'uploads'] },
      { to: '/smtp', label: 'SMTP settings', icon: Mail, keywords: ['email', 'delivery'] },
      { to: '/email-template', label: 'Email template', icon: Mail, keywords: ['email', 'html', 'layout', 'reset', 'verification', 'invitation'] },
    ] },
    { id: 'appearance', label: 'Appearance', icon: Palette, children: [
      { to: '/appearance', label: 'Branding', icon: PanelTop },
      { to: '/theme', label: 'Theme styling', icon: Palette },
    ] },
  ],
}];
export const routeTitle = (path, navigation = PLATFORM_NAV) =>
  path === '/account/settings' ? 'Account settings' : path === '/profile' ? 'My account' : path === '/about' ? 'About us'
    : path === '/notifications' ? 'Notifications'
    : navigationTrail(path, navigation).at(-1)?.label || 'Back office';
export const backTargetFor = (path) => (path === '/profile' ? '/' : null);
