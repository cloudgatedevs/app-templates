import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { RefreshCw, Save, UserPlus } from 'lucide-react';
import { useCloudgate } from '../context.jsx';
import { Badge, ErrorNote, PageHead, Spinner } from '../components/ui.jsx';
import { Notice } from '../components/forms.jsx';

export function Registration() {
  const { client } = useCloudgate();
  const [saved, setSaved] = useState(null), [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false);
  const [error, setError] = useState(null), [notice, setNotice] = useState('');
  const pending = useRef(null), lock = useRef(false);
  const id = useId();
  const load = useCallback(async () => {
    pending.current?.abort();
    const request = new AbortController(); pending.current = request;
    setLoading(true); setError(null); setNotice(''); setSaved(null);
    try {
      const value = await client.registration.get({ signal: request.signal });
      if (!request.signal.aborted) { setSaved(value); setEnabled(value.allowSelfRegistration); }
    } catch (failure) { if (!request.signal.aborted) setError(failure); }
    finally { if (!request.signal.aborted) setLoading(false); }
  }, [client]);
  useEffect(() => { load(); return () => pending.current?.abort(); }, [load]);
  const save = async event => {
    event.preventDefault();
    if (lock.current || !saved || saved.allowSelfRegistration === enabled) return;
    lock.current = true; setBusy(true); setError(null); setNotice('');
    const request = new AbortController(); pending.current = request;
    try {
      const value = await client.registration.update({ allowSelfRegistration: enabled }, { signal: request.signal });
      if (!request.signal.aborted) {
        setSaved(value); setEnabled(value.allowSelfRegistration);
        setNotice(`Self-registration ${value.allowSelfRegistration ? 'enabled' : 'disabled'} for this tenant.`);
      }
    } catch (failure) {
      if (!request.signal.aborted) {
        setError(failure);
        // A revoked IdP Admin role or unavailable endpoint must be rechecked before another edit.
        if ([401, 403, 404].includes(failure.status)) setSaved(null);
      }
    } finally { lock.current = false; if (!request.signal.aborted) setBusy(false); }
  };
  const dirty = saved && enabled !== saved.allowSelfRegistration;
  return <div className="space-y-5">
    <PageHead title="Registration" subtitle="Control who can create an account through your apps.">
      <button type="button" className="btn-ghost" onClick={load} disabled={loading || busy}><RefreshCw size={14} /> Reload setting</button>
    </PageHead>
    <Notice>This setting applies to all apps in your Cloudgate tenant, across sandbox and production.</Notice>
    {loading ? <Spinner /> : <>
      <ErrorNote error={error} />
      <Notice>{notice}</Notice>
      <form onSubmit={save} className="card max-w-3xl p-5">
        <fieldset disabled={busy || !saved}>
          <div className="flex items-start gap-3">
            <span className="stat-icon shrink-0"><UserPlus size={17} aria-hidden="true" /></span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <label htmlFor={id} className="flex min-h-10 cursor-pointer items-center gap-3 text-sm font-semibold">
                  <input id={id} type="checkbox" role="switch" checked={enabled}
                    aria-describedby={`${id}-description`} className="h-4 w-4 accent-accent"
                    onChange={event => { setEnabled(event.target.checked); setNotice(''); }} />
                  Allow self-registration
                </label>
                {saved ? <Badge tone={saved.allowSelfRegistration ? 'green' : 'gray'}>Currently {saved.allowSelfRegistration ? 'enabled' : 'disabled'}</Badge> : <Badge>Not loaded</Badge>}
              </div>
              <p id={`${id}-description`} className="mt-1 text-sm leading-relaxed text-mist-muted">
                When enabled, new users can sign up through your app's registration flow. When disabled, public sign-up cannot create accounts; administrators can still add users. Existing users can still sign in.
              </p>
              <p className="mt-3 text-xs leading-relaxed text-mist-dim">Your IdP account must have the Admin role to change this setting. Existing reCAPTCHA and sign-in settings continue to apply.</p>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-ink-700 pt-4">
            <button type="submit" className="btn-primary" disabled={!dirty || busy}><Save size={14} />{busy ? 'Saving…' : 'Save changes'}</button>
            {dirty && <span className="text-xs text-mist-dim">Unsaved changes</span>}
          </div>
        </fieldset>
      </form>
    </>}
  </div>;
}
